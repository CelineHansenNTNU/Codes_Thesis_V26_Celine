function out = snr_spectrum_from_files_4(files, shiftRange)
    % out: struct with fields ramanShift, mu, sd, snr, YI and files
    % SNR(shift) = mean(YI, 2)./ std(YI, 0, 2) where YI = zeros(nPts, nRep);
    % nPts = numel(ramanShift); nRep = numel(Ys);

    %if nargin < 2, shiftRange = [0 3500]; end % Default shift range
    %assert(numel(files) >= 2, 'Need at least 2 replicates'); % Ensure at least 2 files

    % Read files
    S = cellfun(@(f) tgspcread(f,Verbose=false), files, 'uni', 0);
    Xs = cellfun(@(s)s.X(:), S, 'uni', 0);
    Ys = cellfun(@(s)s.Y(:), S, 'uni', 0);

    % Determine the range based on shiftRange
    xmin = max(cellfun(@min, Xs)); 
    xmax = min(cellfun(@max, Xs));
    x = Xs{1}; % Create a common x range
    mask=find(x>shiftRange(1) & x<shiftRange(2));
    x=x(mask);

    YI = zeros(numel(x), numel(Ys));
    for k = 1:numel(Ys)
        y = Ys{k};
        YI(:, k) = y(mask); % Assuming y is already aligned with x
    end
    YI3=transpose(PreprocessingSpectrasMsSnvSg(transpose(YI),x,1));

    % Calculate mean, standard deviation, and SNR
    mu = mean(YI, 2);
    sd = std(YI, 0, 2);
    snr = mu ./ sd;

    %ok = isfinite(x) & isfinite(snr);
    out.ramanShift = x;
    out.mu = mu;
    out.sd = sd;
    out.snr = snr;
    out.YI = YI;
    out.files = files;
    out.mu3=mean(YI3,2);
    out.sd3=std(YI3,0,2);
    out.YI3=YI3;
end
